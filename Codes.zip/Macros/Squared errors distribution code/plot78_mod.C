void plot78_mod(){
//This code represents number of events as a function of squared errors from mean
//1st graph:Y = number of events having squared error from mean = X
const char *files[6]={"pytree020;24","pytree2040;28","pytree4060;24","pytree6080;16","pytree80100;7","pytree100;3"};
for(int k=0;k<6;k++){
TTree *t=new TTree("t","myTree");
TFile *f=new TFile("/home/rhishabh/ph219_project/file1/13TeV_CR0_RHoff.root"); 
Int_t pid[192];
Int_t ntrack;
Double_t pT[192]; 
Double_t rap[192];
Double_t eta[192];
Double_t phi[192];
gDirectory->GetObject(files[k],t);
t->SetBranchAddress("pid",pid);
t->SetBranchAddress("pT",pT);
t->SetBranchAddress("eta",eta);
t->SetBranchAddress("rap",rap);
t->SetBranchAddress("phi",phi);
t->SetBranchAddress("ntrack",&ntrack);
size_t n=(size_t)t->GetEntries();
Int_t net=0;
double mse=0;
double m_net=0;
double max_mse=0;
for(size_t i=0;i<n;i++){
mse=0;
t->GetEntry(i);
//finding max squared error
for(size_t j=0;j<ntrack;j++){
    if(eta[j]<1&&eta[j]>-1&&pT[j]>0.05){
    if(pid[j]>0){
        net=net+1;
    }
    else if (pid[j]<0){
        net=net-1;
    }
    }
}
} 
m_net= (double)net/n;
for(size_t i=0;i<n;i++){
    Int_t nc=0;
t->GetEntry(i);
    for(size_t j=0;j<ntrack;j++){
        if(pid[j]>0){
            nc+=1;
        }
        else if (pid[j]<0){
            nc-=1;
    }
}

mse =(nc-m_net)*(nc-m_net);
if (mse>max_mse){
    max_mse=mse;
}

}
TH1D *hist1=new TH1D("hist1","Distribution of squared errors of net charge from mean net charge",max_mse,-100,max_mse); 
//filling histogram
for(size_t i=0;i<n;i++){
    Int_t nc=0;
t->GetEntry(i);
    for(size_t j=0;j<ntrack;j++){
        if(pid[j]>0){
            nc+=1;
        }
        else if (pid[j]<0){
            nc-=1;
    }
}

mse =(nc-m_net)*(nc-m_net);
hist1->Fill(mse,1);
}

cout<<k+1<<"/"<<"6"<<endl;
std::cout<<"\nMax mse of tree "<<files[k]<<"= "<<max_mse;

TCanvas *c1=new TCanvas("c2","Charge distributions");
hist1->Draw();
hist1->GetXaxis()->SetTitle("Squared difference between net charge of event and mean net charge");
hist1->GetYaxis()->SetTitle("Number of events");
c1->Update();
string s="/mnt/c/Users/Rhishabh/Desktop/PH219_project/mse_distribution";
string nums= to_string(k+1); //to_string converts integer to string
const char* fin=nums.c_str(); 
s.append(fin);
s.append(".jpg");
const char* address=s.c_str();
c1->SaveAs(address);
hist1->Reset("ICESM");
}
}