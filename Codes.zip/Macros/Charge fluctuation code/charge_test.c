void charge_test(){
const char *files[6]={"pytree020;24","pytree2040;28","pytree4060;24","pytree6080;16","pytree80100;7","pytree100;3"};
Int_t bins[6]={2380460,873322,445805,207990,71263,20981};
for(int k=0;k<6;k++){   
TH1D *hist1=new TH1D("hist1","positive charge fluctuations",bins[k],0,bins[k]); 
TH1D *hist2=new TH1D("hist2","negative charge fluctuations",bins[k],0,bins[k]);
TH1D *hist3=new TH1D("hist3","net charge fluctuations",bins[k],0,bins[k]);
TTree *t=new TTree("t","myTree");
TFile *f=new TFile("/home/rhishabh/ph219_project/file1/13TeV_CR0_RHoff.root"); 
Int_t pid[192];
Int_t ntrack;
Double_t pT[192]; 
Double_t rap[192];
Double_t eta[192];
Double_t phi[192];
gDirectory->GetObject(files[k],t);
t->SetBranchAddress("pid",pid);
t->SetBranchAddress("pT",pT);
t->SetBranchAddress("eta",eta);
t->SetBranchAddress("rap",rap);
t->SetBranchAddress("phi",phi);
t->SetBranchAddress("ntrack",&ntrack);
size_t n=(size_t)t->GetEntries();
Int_t np;
Int_t nn;
Int_t net;
for(size_t i=0;i<n;i++){
np=0;
nn=0;   
net=0; 
t->GetEntry(i);
for(size_t j=0;j<ntrack;j++){
    if(eta[j]<1&&eta[j]>-1&&pT[j]>0.05){
    if(pid[j]>0){
        np=np+1;
    }
    else if (pid[j]<0){
        nn=nn-1;
    }
    }
}
net=np+nn;    
hist1->Fill(i,np);
hist2->Fill(i,nn);
hist3->Fill(i,net);
}
cout<<k+1<<"/"<<"14"<<endl;
TCanvas *c2=new TCanvas("c2","Charge fluctuations");
//c2->Divide(1,3);
//c2->cd(1);
hist1->GetXaxis()->SetTitle("Events");
hist1->GetYaxis()->SetTitle("Net Positive charge per event in acceptance region");
gStyle->SetOptStat(11);
hist1->SetStats(1);
hist1->Draw();
//c2->cd(2);
//hist2->GetXaxis()->SetTitle("Events");
//hist2->GetYaxis()->SetTitle("Net negative charge per event in acceptance region");
//gStyle->SetOptStat(11);
//hist2->SetStats(1);
//hist2->Draw();
//c2->cd(3);
//hist3->GetXaxis()->SetTitle("Events");
//hist3->GetYaxis()->SetTitle("Net charge per event in acceptance region");
//gStyle->SetOptStat(11);
//hist3->SetStats(1);
//hist3->Draw();
c2->Update();
string s="/mnt/c/Users/Rhishabh/Desktop/PH219_project/positive_charge_fluctuations_plot";
string nums= to_string(k+1); //to_string converts integer to string
const char* fin=nums.c_str(); 
s.append(fin);
s.append(".jpg");
const char* address=s.c_str();
c2->SaveAs(address);
hist1->Reset("ICESM");
hist2->Reset("ICESM");
hist3->Reset("ICESM");
}
}