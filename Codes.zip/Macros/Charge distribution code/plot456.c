void plot456(){
//This code represents number of events as a function of charge
//1st graph: Y axis would be number of events having total positive charge = X-axis
//2nd graph: Y axis would be number of events having total negative charge = X-axis
//3rd graph: Y axis would be number of events having total charge = X-axis  
const char *files[6]={"pytree020;24","pytree2040;28","pytree4060;24","pytree6080;16","pytree80100;7","pytree100;3"};
TH1D *hist1=new TH1D("hist1","Number of events having total positive charge of particles in acceptance region = X",1000,0,100); 
TH1D *hist2=new TH1D("hist2","Number of events having total negative charge of particles in acceptance region= X",1000,-100,0);
TH1D *hist3=new TH1D("hist3","Number of events having total charge of particles in acceptance region = X",1000,-100,100);
for(int k=0;k<6;k++){
TTree *t=new TTree("t","myTree");
TFile *f=new TFile("/home/rhishabh/ph219_project/file1/13TeV_CR0_RHoff.root"); 
Int_t pid[192];
Int_t ntrack;
Double_t pT[192]; 
Double_t rap[192];
Double_t eta[192];
Double_t phi[192];
gDirectory->GetObject(files[k],t);
t->SetBranchAddress("pid",pid);
t->SetBranchAddress("pT",pT);
t->SetBranchAddress("eta",eta);
t->SetBranchAddress("rap",rap);
t->SetBranchAddress("phi",phi);
t->SetBranchAddress("ntrack",&ntrack);
size_t n=(size_t)t->GetEntries();
Int_t np;
Int_t nn;
Int_t net;
Double_t dd = 0;
for(size_t i=0;i<n;i++){
np=0;
nn=0;   
net=0; 
t->GetEntry(i);
for(size_t j=0;j<ntrack;j++){
    if(eta[j]>-1&&eta[j]<1&&pT[j]>0.05){
    if(pid[j]>0){
        np=np+1;
    }
    else if (pid[j]<0){
        nn=nn-1;
    }
    }
}
net=np+nn;    
hist1->Fill(np,1);
hist2->Fill(nn,1);
hist3->Fill(net,1);
}
cout<<k+1<<"/"<<"6"<<endl;
TCanvas *c1=new TCanvas("c2","Charge distributions");
hist1->GetXaxis()->SetTitle("Net positive charge in acceptance region per event");
hist1->GetYaxis()->SetTitle("Number of events");
hist1->Draw();
//hist2->GetXaxis()->SetTitle("Net negative charge in acceptance region per event");
//hist2->GetYaxis()->SetTitle("Number of events");
//hist2->Draw();
//hist3->GetXaxis()->SetTitle("Total charge in acceptance per event");
//hist3->GetYaxis()->SetTitle("Number of events");
//hist3->Draw();
c1->Update();
string s="/mnt/c/Users/Rhishabh/Desktop/PH219_project/positive_charge_plot";
string nums= to_string(k+1); //to_string converts integer to string
const char* fin=nums.c_str(); 
s.append(fin);
s.append(".jpg");
const char* address=s.c_str();
c1->SaveAs(address);
hist1->Reset("ICESM");
hist2->Reset("ICESM");
hist3->Reset("ICESM");
}
//
//c2->Divide(1,3);
//c2->cd(1);
//hist1->Draw();
//c2->cd(2);
//hist2->Draw();
//c2->cd(3);
//hist3->Draw();
}