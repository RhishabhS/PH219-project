void plot9(){
const char *files[6]={"pytree020;24","pytree2040;28","pytree4060;24","pytree6080;16","pytree80100;7","pytree100;3"};
Double_t net=0;   
Double_t X[6];
Double_t Y[6];
int p=0;
for(int k=0;k<6;k++){
TTree *t=new TTree("t","myTree");
TFile *f=new TFile("/home/rhishabh/ph219_project/file1/13TeV_CR0_RHoff.root"); 
Int_t pid[192];
Int_t ntrack;
Double_t pT[192]; 
Double_t rap[192];
Double_t eta[192];
Double_t phi[192];
gDirectory->GetObject(files[k],t);
t->SetBranchAddress("pid",pid);
t->SetBranchAddress("pT",pT);
t->SetBranchAddress("eta",eta);
t->SetBranchAddress("rap",rap);
t->SetBranchAddress("phi",phi);
t->SetBranchAddress("ntrack",&ntrack);
size_t n=(size_t)t->GetEntries();
Double_t mmult=0;
Double_t c; //local counter to find mean multiplicity of event
net=0;
Double_t mnc;//want to find net charge from the whole multiplicity class (tree) and use that to find mean net charge.
for(size_t i=0;i<n;i++){
    t->GetEntry(i);
    c=0;
    for(size_t j=0;j<ntrack;j++){
    if(eta[j]<1&&eta[j]>-1&&pT[j]>0.05){
        c+=1;
        if(pid[j]>0){
            net+=1;
        }
        else if (pid[j]<0){
            net-=1;
        }

    }
    }
    mmult+=(Double_t)c/n;
    
}
    mnc=(Double_t)net/n;
    Double_t var=0;
    //to calculate variance
    for(size_t i=0;i<n;i++){
        t->GetEntry(i);
        int nc=0;   // net charge in this event
        for(size_t j=0;j<ntrack;j++){
            if(eta[j]>-1&&eta[j]<1&&pT[j]>0.05){
                if(pid[j]>0){
                    nc+=1;
                }
                if(pid[j]<0){
                    nc-=1;
                }
                 }
            
            
        }
        var+= (nc-mnc)*(nc-mnc);

    }
    var=var/n;
    Y[p]=(Double_t)var/mnc;
    X[p]=mmult;
    p+=1;
    std::cout<<"\nScaled Variance: "<<Y[p]<<"\n";
std::cout<<k+1<<"/"<<6<<"\n";
}
TGraph *g=new TGraph(6,X,Y);
TCanvas *c1=new TCanvas("c2","scaled var vs mult");
g->SetTitle("Scaled Variance of net charge vs Mean multiplicities");
g->GetXaxis()->SetTitle("Mean multiplicities of each tree in acceptance region");
g->GetYaxis()->SetTitle("Scaled variance");
g->SetMarkerColor(2);
g->SetMarkerStyle(20);
g->SetMarkerSize(1.5);
g->Draw("AL");
c1->SaveAs("/mnt/c/Users/Rhishabh/Desktop/PH219_project/scaled_var_mult_plot.jpg");
}