void plot2ab(){
const char *root_file="/home/rhishabh/ph219_project/file1/13TeV_CR0_RHoff.root";//Enter path of root file here    
const char *files[6]={"pytree020;24","pytree2040;28","pytree4060;24","pytree6080;16","pytree80100;7","pytree100;3"};
Double_t maxneta=0;
for(int k=0;k<6;k++){
TTree *t=new TTree("t","myTree");
TFile *f=new TFile(root_file); 
Int_t pid[192];
Int_t ntrack;
Double_t pT[192]; 
Double_t rap[192];
Double_t eta[192];
Double_t phi[192];
gDirectory->GetObject(files[k],t);
t->SetBranchAddress("pid",pid);
t->SetBranchAddress("pT",pT);
t->SetBranchAddress("eta",eta);
t->SetBranchAddress("rap",rap);
t->SetBranchAddress("phi",phi);
t->SetBranchAddress("ntrack",&ntrack);
size_t n=(size_t)t->GetEntries();
Int_t neta=0;
Int_t mult=0;
// to find maxneta
for(size_t i=0;i<n;i++){
    neta=0;
    mult=0;
    t->GetEntry(i); 
    for(Int_t j=0;j<ntrack;j++){
    if(eta[j]>1.5||eta[j]<-1.5){
    neta+=1;
    }
    if((eta[j]>1||eta[j]<-1)||(pT[j]<0.05)){
    mult+=1;
    }
    }
    if(neta>maxneta){
        maxneta=neta;
    }
}
TH1D *hist=new TH1D("hist","Multiplicity distribution- Non Acceptance region",1000,0,maxneta); 
// to plot histogram
for(size_t i=0;i<n;i++){
    neta=0;
    mult=0;
    t->GetEntry(i); 
    for(Int_t j=0;j<ntrack;j++){
    if(eta[j]>1.5||eta[j]<-1.5){
    neta+=1;
    }
    if((eta[j]>1||eta[j]<-1)||(pT[j]<0.05)){
    mult+=1;
    }
    }

hist->Fill(neta,mult);
}
cout<<k+1<<"/"<<"6\n\n"<<endl;
TCanvas *c1=new TCanvas("c2","Multiplicity distributions");
hist->GetXaxis()->SetTitle("Event multiplicity of particles with |#eta#mbox{|>1.5}");
hist->GetYaxis()->SetTitle("Event multiplicity of particles in non-acceptance region");
hist->SetMarkerColor(4);
hist->SetMarkerStyle(20);
hist->SetMarkerSize(1);
hist->Draw();
c1->Update();
string s="/mnt/c/Users/Rhishabh/Desktop/PH219_project/norm_nmult_distribution_tree";
string nums= to_string(k+1); //to_string converts integer to string
const char* fin=nums.c_str(); 
s.append(fin);
s.append(".jpg");
const char* address=s.c_str();
c1->SaveAs(address);
hist->Reset("ICESM");
}
}