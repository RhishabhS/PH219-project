void plot2(){
const char *root_file="/home/rhishabh/ph219_project/file1/13TeV_CR0_RHoff.root";//Enter path of root file here    
const char *files[6]={"pytree020;24","pytree2040;28","pytree4060;24","pytree6080;16","pytree80100;7","pytree100;3"};
TH1D *hist=new TH1D("hist","Overall multiplicity distribution: Non-acceptance region",90,0,90); 
Double_t maxneta=0;
for(int k=0;k<6;k++){
TTree *t=new TTree("t","myTree");
TFile *f=new TFile(root_file); 
Int_t pid[192];
Int_t ntrack;
Double_t pT[192]; 
Double_t rap[192];
Double_t eta[192];
Double_t phi[192];
gDirectory->GetObject(files[k],t);
t->SetBranchAddress("pid",pid);
t->SetBranchAddress("pT",pT);
t->SetBranchAddress("eta",eta);
t->SetBranchAddress("rap",rap);
t->SetBranchAddress("phi",phi);
t->SetBranchAddress("ntrack",&ntrack);
size_t n=(size_t)t->GetEntries();
Double_t neta=0;
Int_t mult=0;
Double_t mneta=0;
for(size_t i=0;i<n;i++){
    neta=0;
    mult=0;
    t->GetEntry(i); 
    for(Int_t j=0;j<ntrack;j++){
    if(eta[j]>1.5||eta[j]<-1.5){
    neta+=1;
    }
    if((eta[j]>1||eta[j]<-1)||(pT[j]<0.05)){
    mult+=1;
    }
    }
    if(neta>maxneta){
        maxneta=neta;
    }
    hist->Fill(neta,mult);
    mneta+=(Double_t)neta/n;
}
cout<<k+1<<"/"<<"6"<<endl;
}
std::cout<<maxneta;
hist->GetXaxis()->SetTitle("Event multiplicity of particles with");
hist->GetYaxis()->SetTitle("Event multiplicity of particles in non-acceptance region");
hist->Draw();
}