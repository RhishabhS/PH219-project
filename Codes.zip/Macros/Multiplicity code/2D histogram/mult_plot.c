void mult_plot(){
    TFile *f= new TFile("data.root");
    const char *files[6]={"pytree020;24","pytree2040;28","pytree4060;24","pytree6080;16","pytree80100;7","pytree100;3"};
    
    TH2D *mult = new TH2D("2D histogram","Multiplicity of acceptance and non-acceptance",140,0,140,140,0,140);
    gStyle->SetPalette(kRainBow);
    for(int whatever = 0; whatever < 6; whatever++){
    
    TTree *tree = (TTree*)f->Get(files[whatever]);
    
    
    const Int_t maxTrack=10000;
    Int_t ntrack = 0;
    Double_t pT[maxTrack];
    Double_t eta[maxTrack];
    Double_t rap[maxTrack];
    Double_t phi[maxTrack];


    tree->SetBranchAddress("ntrack",&ntrack);
    tree->SetBranchAddress("phi",&phi);
    tree->SetBranchAddress("pT",&pT);
    tree->SetBranchAddress("eta",&eta);

    Int_t nenteries = (Int_t)tree->GetEntries();


    


    for(Int_t i = 0; i < nenteries; i++){
        tree->GetEntry(i);
        int count_acc = 0;
        int count_non = 0;
        for(int i = 0; i < ntrack; i++){
            if ((eta[i] < 1.0 && eta[i] > -1.0) && pT[i] > 0.05){
                count_acc += 1;
            }
            else{
                count_non += 1;
            }
        }
        mult->Fill(count_acc, count_non);
       
    }}
    
    mult->GetXaxis()->SetTitle("Acceptance region");
    mult->GetYaxis()->SetTitle("Non-acceptance region");
    mult->GetZaxis()->SetTitle("Event multiplicity");
    mult->SetContour(1000);
    mult->Draw("colz");
    cout<<"Correlation Factor :"<<mult->GetCorrelationFactor()<<endl;
}